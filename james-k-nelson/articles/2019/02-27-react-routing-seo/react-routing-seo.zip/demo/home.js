import React from 'react'

function Home() {
  return (
    <div>
      <h1>Navi</h1>
      <p>Navi is a JavaScript library for mapping URLs to (possibly asynchronous) content.</p>
    </div>
  )
}

export default Home